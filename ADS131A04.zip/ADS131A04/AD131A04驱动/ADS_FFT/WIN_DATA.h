#ifndef __WIN_DATA_H
#define __WIN_DATA_H

extern const float hann_window_1024[1024];
extern const float hann_window_4096[4096];



#endif


