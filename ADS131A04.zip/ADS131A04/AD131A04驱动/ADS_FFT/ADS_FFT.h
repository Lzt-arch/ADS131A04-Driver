#ifndef __ADS_FFT_H
#define __ADS_FFT_H

#include <stdint.h>
#include "arm_math.h"
#include "ads_app.h"

/* FFT点数直接使用ADS驱动的每通道采样点数，当前为1024点。 */
#define ADS_FFT_LEN ADS_SAMPLE_COUNT

#if (ADS_FFT_LEN != 1024U)
#error "ADS_FFT currently requires ADS_SAMPLE_COUNT == 1024"
#endif

typedef enum
{
    ADS_FFT_OK = 0,
    ADS_FFT_ERROR
} ADS_FFT_Status;

typedef struct
{
    float freq;       /* 基波频率，Hz */
    float phaseDeg;   /* 基波绝对相位，度，范围[-180,+180] */
    float phaseRad;   /* 基波绝对相位，rad，范围[-PI,+PI] */
    float thd;        /* 总谐波失真，比例值 */
    float adcMax;     /* 最大电压，V */
    float adcMin;     /* 最小电压，V */
    float adcVpp;     /* 峰峰值，V */
    float duty;       /* 占空比，预留，当前未计算 */
    float average;    /* 平均电压，V */
    uint32_t fundamentalIndex;
    float phaseDiffDeg1_2; /* CH2相对CH1相位差，度 */
    float phaseDiffDeg1_3; /* CH3相对CH1相位差，度 */
    float phaseDiffDeg1_4; /* CH4相对CH1相位差，度 */
    float phaseDiffDeg2_3; /* CH3相对CH2相位差，度 */
    float phaseDiffDeg2_4; /* CH4相对CH2相位差，度 */
    float phaseDiffDeg3_4; /* CH4相对CH3相位差，度 */
} ADC_FFT_Result;

/* 四路独立FFT结果。未选择处理的通道结果保持为0。 */
extern ADC_FFT_Result ADC_Res1;
extern ADC_FFT_Result ADC_Res2;
extern ADC_FFT_Result ADC_Res3;
extern ADC_FFT_Result ADC_Res4;

/*
 * @param process_channels 低4位分别选择CH1..CH4进行FFT，例如0x07处理CH1~CH3；
 *                         可以只处理当前已使能通道中的一部分。
 * @param phase_channels   低4位必须恰有两个1才计算相位，例如0x03计算CH1/CH2；
 *                         0或其它非法位数均按不计算相位处理。
 * FFT直接读取ADS驱动内的整数mV通道缓存，并在模块内部转换为浮点V；
 * 采样率直接使用ADS驱动中的my_ads.sample_rate_hz。
 */
ADS_FFT_Status deal_FFT(uint8_t process_channels,
                        uint8_t phase_channels);

#endif
