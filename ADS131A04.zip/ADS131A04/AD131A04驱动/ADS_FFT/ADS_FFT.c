#include "ADS_FFT.h"
#include <math.h>
#include <string.h>

#define ADS_FFT_PI             3.14159265358979323846f
#define ADS_FFT_HALF_LEN       (ADS_FFT_LEN / 2U)
#define ADS_FFT_MIN_AMPLITUDE  1.0e-6f

ADC_FFT_Result ADC_Res1 = {0};
ADC_FFT_Result ADC_Res2 = {0};
ADC_FFT_Result ADC_Res3 = {0};
ADC_FFT_Result ADC_Res4 = {0};

/* 四个通道依次复用同一组FFT工作区，避免为每路重复分配RAM。 */
static float32_t ads_fft_time[ADS_FFT_LEN];
static float32_t ads_fft_output[ADS_FFT_LEN];
static float32_t ads_fft_magnitude[ADS_FFT_HALF_LEN];
static arm_rfft_fast_instance_f32 ads_fft_instance;
static uint8_t ads_fft_initialized = 0U;

typedef struct
{
    uint32_t index;
    float amplitude;
} ADS_FFT_Analysis;

static float ADS_FFT_Normalize_Phase(float phase)
{
    while (phase > ADS_FFT_PI) {
        phase -= 2.0f * ADS_FFT_PI;
    }
    while (phase < -ADS_FFT_PI) {
        phase += 2.0f * ADS_FFT_PI;
    }
    return phase;
}

static uint8_t ADS_FFT_Count_Bits(uint8_t mask)
{
    uint8_t count = 0U;

    for (uint8_t bit = 0U; bit < 4U; bit++) {
        if ((mask & (1U << bit)) != 0U) {
            count++;
        }
    }
    return count;
}

static ADC_FFT_Result *ADS_FFT_Get_Result(uint8_t channel)
{
    static ADC_FFT_Result *const results[4] = {
        &ADC_Res1, &ADC_Res2, &ADC_Res3, &ADC_Res4
    };

    return (channel < 4U) ? results[channel] : NULL;
}

static ADS_FFT_Status ADS_FFT_Load_Channel(uint8_t channel,
                                           float32_t output[])
{
    const ADS_ChannelData *channel_data;

    if ((channel >= ADS_CHANNEL_COUNT) || (output == NULL)) {
        return ADS_FFT_ERROR;
    }

    channel_data = ADS_Get_Channel((uint8_t)(channel + 1U));
    if ((channel_data == NULL) ||
        (channel_data->enabled == 0U) ||
        (channel_data->millivolts == NULL)) {
        return ADS_FFT_ERROR;
    }

    for (uint32_t i = 0U; i < ADS_FFT_LEN; i++) {
        output[i] = (float32_t)channel_data->millivolts[i] / 1000.0f;
    }
    return ADS_FFT_OK;
}

static void ADS_FFT_Prepare_Windowed(const float input[],
                                     ADC_FFT_Result *result)
{
    float sum = 0.0f;
    float maximum = input[0];
    float minimum = input[0];

    for (uint32_t i = 0U; i < ADS_FFT_LEN; i++) {
        float value = input[i];
        sum += value;
        if (value > maximum) {
            maximum = value;
        }
        if (value < minimum) {
            minimum = value;
        }
    }

    result->adcMax = maximum;
    result->adcMin = minimum;
    result->adcVpp = maximum - minimum;
    result->average = sum / (float)ADS_FFT_LEN;

    for (uint32_t i = 0U; i < ADS_FFT_LEN; i++) {
        /* 运行时生成Hann窗，FFT点数由ADS_SAMPLE_COUNT统一决定。 */
        float window = 0.5f - 0.5f *
            arm_cos_f32((2.0f * ADS_FFT_PI * (float)i) /
                        (float)(ADS_FFT_LEN - 1U));
        ads_fft_time[i] = (input[i] - result->average) * window;
    }
}

static ADS_FFT_Analysis ADS_FFT_Process_Channel(const float input[],
                                                ADC_FFT_Result *result,
                                                uint32_t sampling_rate)
{
    ADS_FFT_Analysis analysis = {0U, 0.0f};
    float fundamental;
    float harmonic_square_sum = 0.0f;

    ADS_FFT_Prepare_Windowed(input, result);
    arm_rfft_fast_f32(&ads_fft_instance, ads_fft_time, ads_fft_output, 0U);
    arm_cmplx_mag_f32(ads_fft_output, ads_fft_magnitude, ADS_FFT_HALF_LEN);

    analysis.index = 1U;
    analysis.amplitude = ads_fft_magnitude[1U];
    for (uint32_t i = 2U; i < ADS_FFT_HALF_LEN; i++) {
        if (ads_fft_magnitude[i] > analysis.amplitude) {
            analysis.amplitude = ads_fft_magnitude[i];
            analysis.index = i;
        }
    }

    result->fundamentalIndex = analysis.index;
    result->freq = ((float)analysis.index * (float)sampling_rate) /
                   (float)ADS_FFT_LEN;
    result->phaseRad = ADS_FFT_Normalize_Phase(
        atan2f(ads_fft_output[2U * analysis.index + 1U],
               ads_fft_output[2U * analysis.index]));
    result->phaseDeg = result->phaseRad * 180.0f / ADS_FFT_PI;

    fundamental = analysis.amplitude;
    for (uint32_t harmonic = 3U; harmonic <= 9U; harmonic += 2U) {
        uint32_t index = harmonic * analysis.index;
        if (index < ADS_FFT_HALF_LEN) {
            float amplitude = ads_fft_magnitude[index];
            if ((index > 1U) &&
                (ads_fft_magnitude[index - 1U] > amplitude)) {
                amplitude = ads_fft_magnitude[index - 1U];
            }
            if (((index + 1U) < ADS_FFT_HALF_LEN) &&
                (ads_fft_magnitude[index + 1U] > amplitude)) {
                amplitude = ads_fft_magnitude[index + 1U];
            }
            harmonic_square_sum += amplitude * amplitude;
        }
    }
    result->thd = (fundamental > ADS_FFT_MIN_AMPLITUDE) ?
                  (sqrtf(harmonic_square_sum) / fundamental) : 0.0f;
    return analysis;
}

static float ADS_FFT_Phase_At_Index(const float input[], uint32_t index)
{
    float sum = 0.0f;

    for (uint32_t i = 0U; i < ADS_FFT_LEN; i++) {
        sum += input[i];
    }
    sum /= (float)ADS_FFT_LEN;

    for (uint32_t i = 0U; i < ADS_FFT_LEN; i++) {
        float window = 0.5f - 0.5f *
            arm_cos_f32((2.0f * ADS_FFT_PI * (float)i) /
                        (float)(ADS_FFT_LEN - 1U));
        ads_fft_time[i] = (input[i] - sum) * window;
    }
    arm_rfft_fast_f32(&ads_fft_instance, ads_fft_time, ads_fft_output, 0U);
    return atan2f(ads_fft_output[2U * index + 1U],
                  ads_fft_output[2U * index]);
}

static void ADS_FFT_Clear_Phase_Differences(void)
{
    ADC_FFT_Result *results[4] = {&ADC_Res1, &ADC_Res2, &ADC_Res3, &ADC_Res4};

    for (uint8_t channel = 0U; channel < 4U; channel++) {
        results[channel]->phaseDiffDeg1_2 = 0.0f;
        results[channel]->phaseDiffDeg1_3 = 0.0f;
        results[channel]->phaseDiffDeg1_4 = 0.0f;
        results[channel]->phaseDiffDeg2_3 = 0.0f;
        results[channel]->phaseDiffDeg2_4 = 0.0f;
        results[channel]->phaseDiffDeg3_4 = 0.0f;
    }
}

static void ADS_FFT_Save_Phase_Difference(uint8_t first,
                                          uint8_t second,
                                          float phase_deg)
{
    ADC_FFT_Result *results[4] = {&ADC_Res1, &ADC_Res2, &ADC_Res3, &ADC_Res4};

    for (uint8_t channel = 0U; channel < 4U; channel++) {
        if ((first == 0U) && (second == 1U)) results[channel]->phaseDiffDeg1_2 = phase_deg;
        else if ((first == 0U) && (second == 2U)) results[channel]->phaseDiffDeg1_3 = phase_deg;
        else if ((first == 0U) && (second == 3U)) results[channel]->phaseDiffDeg1_4 = phase_deg;
        else if ((first == 1U) && (second == 2U)) results[channel]->phaseDiffDeg2_3 = phase_deg;
        else if ((first == 1U) && (second == 3U)) results[channel]->phaseDiffDeg2_4 = phase_deg;
        else if ((first == 2U) && (second == 3U)) results[channel]->phaseDiffDeg3_4 = phase_deg;
    }
}

ADS_FFT_Status deal_FFT(uint8_t process_channels,
                        uint8_t phase_channels)
{
    /* 各通道依次复用此缓存；main.c无需定义或转换FFT输入数组。 */
    static float32_t input[ADS_FFT_LEN];
    ADS_FFT_Analysis analyses[4] = {{0U, 0.0f}};
    uint8_t process_mask = process_channels;
    uint8_t phase_mask = phase_channels;
    uint32_t sampling_rate = (my_ads.measured_sample_rate_hz != 0U) ?
                             my_ads.measured_sample_rate_hz :
                             my_ads.sample_rate_hz;

    if ((process_mask == 0U) || (process_mask > 0x0FU) ||
        ((process_mask & my_ads.channel_mask) != process_mask) ||
        (sampling_rate == 0U)) {
        return ADS_FFT_ERROR;
    }
    if (phase_mask > 0x0FU) {
        phase_mask = 0U;
    }
    if (ads_fft_initialized == 0U) {
        if (arm_rfft_fast_init_f32(&ads_fft_instance, ADS_FFT_LEN) != ARM_MATH_SUCCESS) {
            return ADS_FFT_ERROR;
        }
        ads_fft_initialized = 1U;
    }

    memset(&ADC_Res1, 0, sizeof(ADC_Res1));
    memset(&ADC_Res2, 0, sizeof(ADC_Res2));
    memset(&ADC_Res3, 0, sizeof(ADC_Res3));
    memset(&ADC_Res4, 0, sizeof(ADC_Res4));
    ADS_FFT_Clear_Phase_Differences();

    for (uint8_t channel = 0U; channel < 4U; channel++) {
        if ((process_mask & (1U << channel)) != 0U) {
            if (ADS_FFT_Load_Channel(channel, input) != ADS_FFT_OK) {
                return ADS_FFT_ERROR;
            }
            analyses[channel] = ADS_FFT_Process_Channel(
                input, ADS_FFT_Get_Result(channel), sampling_rate);
        }
    }

    /* 只有恰好选择两个、且两路都已预处理时才计算相位差。 */
    if ((ADS_FFT_Count_Bits(phase_mask) == 2U) &&
        ((phase_mask & process_mask) == phase_mask)) {
        uint8_t first = 0U;
        uint8_t second = 0U;
        uint32_t phase_index;
        float first_phase;
        float second_phase;
        float phase_difference;

        for (uint8_t channel = 0U; channel < 4U; channel++) {
            if ((phase_mask & (1U << channel)) != 0U) {
                first = channel;
                break;
            }
        }
        for (uint8_t channel = (uint8_t)(first + 1U); channel < 4U; channel++) {
            if ((phase_mask & (1U << channel)) != 0U) {
                second = channel;
                break;
            }
        }

        phase_index = analyses[first].index;
        if (analyses[second].amplitude > analyses[first].amplitude) {
            phase_index = analyses[second].index;
        }
        if ((phase_index > 0U) && (phase_index < ADS_FFT_HALF_LEN)) {
            if (ADS_FFT_Load_Channel(first, input) != ADS_FFT_OK) {
                return ADS_FFT_ERROR;
            }
            first_phase = ADS_FFT_Phase_At_Index(input, phase_index);
            if (ADS_FFT_Load_Channel(second, input) != ADS_FFT_OK) {
                return ADS_FFT_ERROR;
            }
            second_phase = ADS_FFT_Phase_At_Index(input, phase_index);
            phase_difference = ADS_FFT_Normalize_Phase(second_phase - first_phase);
            ADS_FFT_Save_Phase_Difference(first, second,
                                           phase_difference * 180.0f / ADS_FFT_PI);
        }
    }

    return ADS_FFT_OK;
}
