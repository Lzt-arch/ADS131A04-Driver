#ifndef STM32H7_ORTH_DEMO_ADS_APP_H
#define STM32H7_ORTH_DEMO_ADS_APP_H

#include <stdint.h>
#include "ads131a0x.h"

/*
 * 单次采集点数。允许范围为 1..ADS_SAMPLE_COUNT_MAX。
 * 修改此宏即可改变每通道静态缓存长度；无需在 main.c 中再定义缓存。
 * 4 通道 raw + mV 缓存占用：ADS_SAMPLE_COUNT * 4 * 2 * 4 字节。
 */
#define ADS_SAMPLE_COUNT_MIN       1U
#define ADS_SAMPLE_COUNT_MAX       1024U
#define ADS_SAMPLE_COUNT           1024U

#if (ADS_SAMPLE_COUNT < ADS_SAMPLE_COUNT_MIN) || \
    (ADS_SAMPLE_COUNT > ADS_SAMPLE_COUNT_MAX)
#error "ADS_SAMPLE_COUNT must be in range 1..1024"
#endif

/* ADS131A04 默认输入时钟。ADS_Start_Input_Clock()会按传入频率动态配置
 * TIM4_CH1(PD12)，并记录定时器实际产生的频率；修改此宏即可改变默认值。
 * 若CLK来自外部而非TIM4，则不调用启动函数，改在ADS_Init()前调用
 * ADS_Set_Input_Clock_Hz()登记实际外部CLK频率。
 */
#define ADS_DEFAULT_INPUT_CLOCK_HZ 16000000UL

#define ADS_CHANNEL_1              0x01U
#define ADS_CHANNEL_2              0x02U
#define ADS_CHANNEL_3              0x04U
#define ADS_CHANNEL_4              0x08U
#define ADS_CHANNEL_ALL            0x0FU
#define ADS_CHANNEL_COUNT          4U

/* 默认采样配置：Fs = CLKIN / ICLK_DIV / MODCLK_DIV / OSR。
 * 当前默认16MHz、/2、/2、OSR=48，对应83.333kSPS；四通道为同步采样。
 * 四通道32位动态帧共160 bit，配合24MHz SPI传输约6.67us，
 * 小于12us的DRDY周期，可避免125kSPS配置下因SPI带宽不足而漏帧。
 */
#define ADS_DEFAULT_ICLK_DIVIDER   ADS_CLK_DIV_2
#define ADS_DEFAULT_MODCLK_DIVIDER ADS_CLK_DIV_2
#define ADS_DEFAULT_OSR            ADS_OSR_DIV_48
#define ADS_DEFAULT_CHANNEL_MASK   (ADS_CHANNEL_1 | ADS_CHANNEL_2)

typedef enum {
    ADS_Init_WAIT = 1,
    ADS_Init_OK,
    ADS_START
} ADS_state;

typedef struct {
    int32_t *raw;                 /* ADC 24位有符号原码 */
    int32_t *millivolts;          /* 换算后的整数mV */
    int32_t min_millivolts;
    int32_t max_millivolts;
    int32_t peak_to_peak_millivolts;
    uint8_t enabled;
    uint8_t gain;
} ADS_ChannelData;

typedef struct {
    uint32_t sample_count;
    volatile uint32_t sample_index;
    uint8_t channel_mask;
    uint8_t frame_words;
    volatile uint8_t samples_ready;
    uint32_t input_clock_hz;
    uint32_t sample_rate_hz;
    uint32_t measured_sample_rate_hz;
    uint8_t iclk_divider;
    uint8_t modclk_divider;
    uint8_t osr;
    uint16_t reference_millivolts;
    uint8_t reference_source;
    ADS_ChannelData channel[ADS_CHANNEL_COUNT];
} ADS_obj;

/* 四个通道始终分配，数组内容单位为整数mV。
 * 4V参考、增益1时理论范围约为-4000..+3999mV；增益越高范围按比例缩小。
 */
extern int32_t ads_ch1_samples[ADS_SAMPLE_COUNT];
extern int32_t ads_ch2_samples[ADS_SAMPLE_COUNT];
extern int32_t ads_ch3_samples[ADS_SAMPLE_COUNT];
extern int32_t ads_ch4_samples[ADS_SAMPLE_COUNT];

extern ADS_obj my_ads;
extern ADS_state my_ads_state;
extern volatile uint32_t ads_debug_raw_frames[4][ADS_MAX_FRAME_WORDS];
extern volatile uint32_t ads_spi_error_count;

/* 配置顺序：输入时钟 -> 采样频率 -> 通道 -> 初始化 -> 开始。 */
ADS_res ADS_Set_Input_Clock_Hz(uint32_t input_clock_hz);
ADS_res ADS_Start_Input_Clock(uint32_t requested_clock_hz);
ADS_res ADS_Set_Sample_Rate(uint8_t iclk_divider,
                            uint8_t modclk_divider,
                            uint8_t osr);
ADS_res ADS_Set_CH_Enable(uint8_t channel_mask);
ADS_res ADS_Set_Channel_Gain(uint8_t channel_index, uint8_t gain);
ADS_res ADS_Set_Reference(uint16_t reference_millivolts,
                          uint8_t reference_source);
ADS_res ADS_Init(void);
ADS_res ADS_Start(void);
ADS_res ADS_Stop(void);

uint8_t ADS_Samples_Ready(void);
ADS_res ADS_Process_Data(void);
ADS_res ADS_Process_Only(void);
const ADS_ChannelData *ADS_Get_Channel(uint8_t channel_index);
void ADS_Print_Init_Info(void);
void ADS_Print_Diagnostics(void);
void ADS_Print_Channel(uint8_t channel_index, uint8_t print_each_sample);
ADS_res ADS_Process_And_Print(uint8_t print_each_sample);

/* 保留在 HAL_GPIO_EXTI_Callback() 中调用。 */
void ADS_DRDY_Callback(void);

/*还可继续封装的项目
以下项目目前部分仍由 CubeMX 或底层驱动配置，可根据需要继续封装：

SPI 波特率：spi.c 中的 BaudRatePrescaler
SPI 模式：当前为 CPOL=0、CPHA=第二边沿
SPI 数据宽度：当前为 32 bit
SPI 超时时间
CRC/Hamming 校验模式
固定帧或动态帧模式
状态字、CRC 字是否包含在帧中
内部/外部参考及参考电压
每通道 PGA 增益
STANDBY、WAKEUP、RESET、LOCK、UNLOCK
连续采集、循环采集、乒乓缓存
DRDY 中断优先级
SPI DMA 采集*/

#endif
