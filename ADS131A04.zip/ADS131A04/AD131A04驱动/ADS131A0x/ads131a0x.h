#ifndef STM32H7_ORTH_DEMO_ADS131A0X_H
#define STM32H7_ORTH_DEMO_ADS131A0X_H

#include <stdint.h>
#include "main.h"
#include "spi.h"

typedef enum {
    ADS_OK = 0,
    ADS_ERROR
} ADS_res;

#define ADS_MAX_FRAME_WORDS 5U

/* 系统命令（16位）。 */
#define ADS_NULL  0x0000U
#define RESET     0x0011U
#define STANDBY   0x0022U
#define WAKEUP    0x0033U
#define LOCK      0x0555U
#define UNLOCK    0x0655U
#define READ_CMD  0x20U
#define WRITE_CMD 0x40U

/* 寄存器地址。 */
#define STAT_1    0x02U
#define STAT_P    0x03U
#define STAT_N    0x04U
#define STAT_S    0x05U
#define ERROR_CNT 0x06U
#define STAT_M2   0x07U
#define A_SYS_CFG 0x0BU
#define D_SYS_CFG 0x0CU
#define CLK1      0x0DU
#define CLK2      0x0EU
#define ADC_ENA   0x0FU
#define ADS_ADC1  0x11U
#define ADS_ADC2  0x12U
#define ADS_ADC3  0x13U
#define ADS_ADC4  0x14U

/* CLK1.CLK_DIV 与 CLK2.ICLK_DIV 编码：实际除数为编码的2倍。 */
#define ADS_CLK_DIV_2  1U
#define ADS_CLK_DIV_4  2U
#define ADS_CLK_DIV_6  3U
#define ADS_CLK_DIV_8  4U
#define ADS_CLK_DIV_10 5U
#define ADS_CLK_DIV_12 6U
#define ADS_CLK_DIV_14 7U

/* 兼容旧命名。 */
#define ADS_INCLK_DIV_2  ADS_CLK_DIV_2
#define ADS_INCLK_DIV_4  ADS_CLK_DIV_4
#define ADS_INCLK_DIV_6  ADS_CLK_DIV_6
#define ADS_INCLK_DIV_8  ADS_CLK_DIV_8
#define ADS_INCLK_DIV_10 ADS_CLK_DIV_10
#define ADS_INCLK_DIV_12 ADS_CLK_DIV_12
#define ADS_INCLK_DIV_14 ADS_CLK_DIV_14

#define ADS_OSR_DIV_4096 0U
#define ADS_OSR_DIV_2048 1U
#define ADS_OSR_DIV_1024 2U
#define ADS_OSR_DIV_800  3U
#define ADS_OSR_DIV_768  4U
#define ADS_OSR_DIV_512  5U
#define ADS_OSR_DIV_400  6U
#define ADS_OSR_DIV_384  7U
#define ADS_OSR_DIV_256  8U
#define ADS_OSR_DIV_200  9U
#define ADS_OSR_DIV_192  10U
#define ADS_OSR_DIV_128  11U
#define ADS_OSR_DIV_96   12U
#define ADS_OSR_DIV_64   13U
#define ADS_OSR_DIV_48   14U
#define ADS_OSR_DIV_32   15U

#define ADC_ALL_ENABLE  0x0FU
#define ADC_ALL_DISABLE 0x00U

#define ADCX_GAIN_1  0x00U
#define ADCX_GAIN_2  0x01U
#define ADCX_GAIN_4  0x02U
#define ADCX_GAIN_8  0x03U
#define ADCX_GAIN_16 0x04U

#define ADS_REF_2V442  0U
#define ADS_REF_4V     1U
#define ADS_REF_EXTERNAL 0U
#define ADS_REF_INTERNAL 1U

HAL_StatusTypeDef ADS131A04_Transfer_Frame(uint16_t command,
                                           uint8_t frame_words,
                                           uint32_t *rx_data);
uint32_t ADS131A04_Write_Command(uint32_t command);
uint32_t ADS131A04_Write_Reg(uint8_t reg_add, uint8_t data);
uint32_t ADS131A04_Read_Reg(uint8_t reg_add, uint8_t frame_words);
uint8_t ADS131A04_Response_Data(uint32_t response);

ADS_res ADS131A04_Set_Clock(uint8_t iclk_divider,
                            uint8_t modclk_divider,
                            uint8_t osr);
ADS_res ADS131A04_Set_Reference(uint8_t ref_mode, uint8_t ref_source);
ADS_res ADS131A04_Set_Gain(uint8_t channel_register, uint8_t gain);
ADS_res ADS131A04_Enable_Channels(uint8_t channel_mask, uint8_t frame_words);
ADS_res ADS131A04_Power_Up(void);
ADS_res ADS131A04_Wakeup(uint8_t frame_words);

uint16_t ADS131A04_Get_OSR_Value(uint8_t osr);

#endif
