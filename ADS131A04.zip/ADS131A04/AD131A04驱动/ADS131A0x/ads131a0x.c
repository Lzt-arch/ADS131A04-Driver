#include "ads131a0x.h"
#include <stdio.h>

/* 正常初始化日志关闭；通信失败等错误信息仍使用printf输出。 */
#define ADS_INFO_PRINTF(...) ((void)0)

static uint8_t ADS131A04_Count_Channels(uint8_t channel_mask)
{
    uint8_t count = 0U;

    for (uint8_t channel = 0U; channel < 4U; channel++) {
        if ((channel_mask & (1U << channel)) != 0U) {
            count++;
        }
    }
    return count;
}

static void ADS131A04_CS_High_Delay(void)
{
    for (volatile uint32_t delay = 0U; delay < 8U; delay++) {
        __NOP();
    }
}

HAL_StatusTypeDef ADS131A04_Transfer_Frame(uint16_t command,
                                           uint8_t frame_words,
                                           uint32_t *rx_data)
{
    uint32_t tx_data[ADS_MAX_FRAME_WORDS] = {0U};
    HAL_StatusTypeDef status;

    if ((frame_words == 0U) || (frame_words > ADS_MAX_FRAME_WORDS) ||
        (rx_data == NULL)) {
        return HAL_ERROR;
    }

    tx_data[0] = ((uint32_t)command) << 16;
    ADS131A04_CS_High_Delay();
    HAL_GPIO_WritePin(ADS_CS_GPIO_Port, ADS_CS_Pin, GPIO_PIN_RESET);
    status = HAL_SPI_TransmitReceive(&hspi2,
                                     (uint8_t *)tx_data,
                                     (uint8_t *)rx_data,
                                     frame_words,
                                     300U);
    HAL_GPIO_WritePin(ADS_CS_GPIO_Port, ADS_CS_Pin, GPIO_PIN_SET);
    ADS131A04_CS_High_Delay();
    return status;
}

uint32_t ADS131A04_Write_Command(uint32_t command)
{
    uint32_t response = 0U;

    if (ADS131A04_Transfer_Frame((uint16_t)command, 1U, &response) != HAL_OK) {
        return 0U;
    }
    return response;
}

uint32_t ADS131A04_Write_Reg(uint8_t reg_add, uint8_t data)
{
    uint16_t command = (uint16_t)(((uint16_t)reg_add << 8) | data);

    ADS131A04_Write_Command(command);
    return ADS131A04_Write_Command(ADS_NULL);
}

uint32_t ADS131A04_Read_Reg(uint8_t reg_add, uint8_t frame_words)
{
    uint32_t response[ADS_MAX_FRAME_WORDS] = {0U};
    uint16_t command = (uint16_t)(((uint16_t)(READ_CMD | reg_add)) << 8);

    if (ADS131A04_Transfer_Frame(command, frame_words, response) != HAL_OK) {
        return 0U;
    }
    if (ADS131A04_Transfer_Frame(ADS_NULL, frame_words, response) != HAL_OK) {
        return 0U;
    }
    return response[0];
}

uint8_t ADS131A04_Response_Data(uint32_t response)
{
    return (uint8_t)((response >> 16) & 0xFFU);
}

uint16_t ADS131A04_Get_OSR_Value(uint8_t osr)
{
    static const uint16_t osr_table[16] = {
        4096U, 2048U, 1024U, 800U, 768U, 512U, 400U, 384U,
        256U, 200U, 192U, 128U, 96U, 64U, 48U, 32U
    };

    return (osr < 16U) ? osr_table[osr] : 0U;
}

ADS_res ADS131A04_Set_Clock(uint8_t iclk_divider,
                            uint8_t modclk_divider,
                            uint8_t osr)
{
    uint32_t response;

    if ((iclk_divider < ADS_CLK_DIV_2) || (iclk_divider > ADS_CLK_DIV_14) ||
        (modclk_divider < ADS_CLK_DIV_2) || (modclk_divider > ADS_CLK_DIV_14) ||
        (osr > ADS_OSR_DIV_32)) {
        return ADS_ERROR;
    }

    response = ADS131A04_Write_Reg(WRITE_CMD | CLK1,
                                   (uint8_t)(iclk_divider << 1));
    ADS_INFO_PRINTF("CLK1 write response: 0x%08lX\r\n", (unsigned long)response);

    response = ADS131A04_Write_Reg(WRITE_CMD | CLK2,
                                   (uint8_t)((modclk_divider << 5) | osr));
    ADS_INFO_PRINTF("CLK2 write response: 0x%08lX\r\n", (unsigned long)response);
    return ADS_OK;
}

ADS_res ADS131A04_Set_Reference(uint8_t ref_mode, uint8_t ref_source)
{
    uint8_t value = 0x60U;
    uint32_t response;

    if ((ref_mode > ADS_REF_4V) || (ref_source > ADS_REF_INTERNAL)) {
        return ADS_ERROR;
    }
    if (ref_mode == ADS_REF_4V) {
        value |= 0x10U;
    }
    if (ref_source == ADS_REF_INTERNAL) {
        value |= 0x08U;
    }

    response = ADS131A04_Write_Reg(WRITE_CMD | A_SYS_CFG, value);
    ADS_INFO_PRINTF("Reference write response: 0x%08lX\r\n", (unsigned long)response);
    return ADS_OK;
}

ADS_res ADS131A04_Set_Gain(uint8_t channel_register, uint8_t gain)
{
    if ((channel_register < ADS_ADC1) || (channel_register > ADS_ADC4) ||
        (gain > ADCX_GAIN_16)) {
        return ADS_ERROR;
    }
    ADS131A04_Write_Reg(WRITE_CMD | channel_register, gain);
    return ADS_OK;
}

ADS_res ADS131A04_Power_Up(void)
{
    uint32_t frame_response[ADS_MAX_FRAME_WORDS] = {0U};
    uint32_t response = 0U;
    uint32_t retry;
    uint8_t reset_frame_words;
    uint8_t ready_received = 0U;

    /*
     * ADS启用通道后处于动态帧模式，软复位命令必须使用芯片当前帧长度。
     * MCU复位并不会同时复位ADS，因此依次尝试1..5 words，可兼容芯片
     * 仍停留在任意上一次通道配置的情况。RESET成功后寄存器恢复默认，
     * ADC_ENA=0，后续READY轮询重新使用1-word帧。
     */
    for (reset_frame_words = 1U;
         (reset_frame_words <= ADS_MAX_FRAME_WORDS) && (ready_received == 0U);
         reset_frame_words++) {
        ADS_INFO_PRINTF("RESET try: frame=%u words\r\n",
                (unsigned int)reset_frame_words);
        if (ADS131A04_Transfer_Frame(RESET,
                                     reset_frame_words,
                                     frame_response) != HAL_OK) {
            continue;
        }

        HAL_Delay(1U);
        for (retry = 0U; retry < 20U; retry++) {
            response = ADS131A04_Write_Command(ADS_NULL);
            if (response == 0xFF040000U) {
                ready_received = 1U;
                break;
            }
        }
    }

    if (ready_received == 0U) {
        printf("ADS131A04 READY timeout, last=0x%08lX\r\n",
               (unsigned long)response);
        return ADS_ERROR;
    }
    ADS_INFO_PRINTF("ADS131A04 READY received after %u-word RESET\r\n",
                    (unsigned int)(reset_frame_words - 1U));

    for (retry = 0U; retry < 5U; retry++) {
        ADS131A04_Write_Command(UNLOCK);
        response = ADS131A04_Write_Command(ADS_NULL);
        ADS_INFO_PRINTF("UNLOCK[%lu] ack=0x%08lX\r\n",
                (unsigned long)retry, (unsigned long)response);
        if ((response & 0xFFFF0000U) == 0x06550000U) {
            return ADS_OK;
        }
    }

    printf("UNLOCK failed: check PB15(MOSI), ADS DIN and SPI mode\r\n");
    return ADS_ERROR;
}

ADS_res ADS131A04_Enable_Channels(uint8_t channel_mask, uint8_t frame_words)
{
    uint32_t response[ADS_MAX_FRAME_WORDS] = {0U};
    uint32_t register_value;
    uint16_t command;

    if ((channel_mask == 0U) || (channel_mask > ADC_ALL_ENABLE) ||
        (frame_words != (uint8_t)(1U + ADS131A04_Count_Channels(channel_mask)))) {
        return ADS_ERROR;
    }

    command = (uint16_t)(((uint16_t)(WRITE_CMD | ADC_ENA) << 8) | channel_mask);
    ADS131A04_Write_Command(command);

    if (ADS131A04_Transfer_Frame(ADS_NULL, frame_words, response) != HAL_OK) {
        return ADS_ERROR;
    }
    ADS_INFO_PRINTF("ADC_ENABLE ack: 0x%08lX\r\n", (unsigned long)response[0]);

    register_value = ADS131A04_Read_Reg(ADC_ENA, frame_words);
    ADS_INFO_PRINTF("REG ADC_ENA raw=0x%08lX data=0x%02X\r\n",
                    (unsigned long)register_value,
                    ADS131A04_Response_Data(register_value));
    return (ADS131A04_Response_Data(register_value) == channel_mask) ?
           ADS_OK : ADS_ERROR;
}

ADS_res ADS131A04_Wakeup(uint8_t frame_words)
{
    uint32_t response[ADS_MAX_FRAME_WORDS] = {0U};

    if (ADS131A04_Transfer_Frame(WAKEUP, frame_words, response) != HAL_OK) {
        return ADS_ERROR;
    }
    if (ADS131A04_Transfer_Frame(ADS_NULL, frame_words, response) != HAL_OK) {
        return ADS_ERROR;
    }
    ADS_INFO_PRINTF("WAKEUP ack/status: 0x%08lX\r\n", (unsigned long)response[0]);
    return ADS_OK;
}
