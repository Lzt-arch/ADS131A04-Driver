#include "ads_app.h"
#include "tim.h"
#include <stdio.h>
#include <string.h>

/* 正常运行日志关闭；错误信息和main.c中的FFT结果仍使用printf输出。 */
#define ADS_INFO_PRINTF(...) ((void)0)

/* 原始码仅供驱动内部换算；对外的 ads_chX_samples 均为整数mV。 */
static int32_t ads_ch1_raw[ADS_SAMPLE_COUNT];
static int32_t ads_ch2_raw[ADS_SAMPLE_COUNT];
static int32_t ads_ch3_raw[ADS_SAMPLE_COUNT];
static int32_t ads_ch4_raw[ADS_SAMPLE_COUNT];

int32_t ads_ch1_samples[ADS_SAMPLE_COUNT];
int32_t ads_ch2_samples[ADS_SAMPLE_COUNT];
int32_t ads_ch3_samples[ADS_SAMPLE_COUNT];
int32_t ads_ch4_samples[ADS_SAMPLE_COUNT];

ADS_obj my_ads = {
    .sample_count = ADS_SAMPLE_COUNT,
    .sample_index = 0U,
    .channel_mask = 0U,
    .frame_words = 1U,
    .samples_ready = 0U,
    .input_clock_hz = ADS_DEFAULT_INPUT_CLOCK_HZ,
    .sample_rate_hz = 0U,
    .measured_sample_rate_hz = 0U,
    .iclk_divider = ADS_CLK_DIV_2,
    .modclk_divider = ADS_CLK_DIV_2,
    .osr = ADS_OSR_DIV_48,
    .reference_millivolts = 4000U,
    .reference_source = ADS_REF_INTERNAL,
    .channel = {
        {ads_ch1_raw, ads_ch1_samples, 0, 0, 0, 0U, ADCX_GAIN_1},
        {ads_ch2_raw, ads_ch2_samples, 0, 0, 0, 0U, ADCX_GAIN_1},
        {ads_ch3_raw, ads_ch3_samples, 0, 0, 0, 0U, ADCX_GAIN_1},
        {ads_ch4_raw, ads_ch4_samples, 0, 0, 0, 0U, ADCX_GAIN_1}
    }
};

ADS_state my_ads_state = ADS_Init_WAIT;
volatile uint32_t ads_debug_raw_frames[4][ADS_MAX_FRAME_WORDS] = {{0U}};
volatile uint32_t ads_spi_error_count = 0U;

static uint8_t ADS_Count_Channels(uint8_t channel_mask)
{
    uint8_t count = 0U;

    for (uint8_t channel = 0U; channel < ADS_CHANNEL_COUNT; channel++) {
        if ((channel_mask & (1U << channel)) != 0U) {
            count++;
        }
    }
    return count;
}

static uint8_t ADS_Gain_Value(uint8_t gain)
{
    static const uint8_t gain_table[5] = {1U, 2U, 4U, 8U, 16U};
    return (gain <= ADCX_GAIN_16) ? gain_table[gain] : 1U;
}

static int32_t ADS_Sign_Extend_24(uint32_t word)
{
    uint32_t value = word >> 8;

    if ((value & 0x00800000U) != 0U) {
        value |= 0xFF000000U;
    }
    return (int32_t)value;
}

static int32_t ADS_Raw_To_Millivolts(int32_t raw, uint8_t gain)
{
    /* 满量程差分输入为 +/-VREF/gain。 */
    int64_t denominator = 8388608LL * ADS_Gain_Value(gain);
    return (int32_t)(((int64_t)raw * my_ads.reference_millivolts) /
                     denominator);
}

ADS_res ADS_Set_Input_Clock_Hz(uint32_t input_clock_hz)
{
    if ((input_clock_hz < 1000000UL) || (input_clock_hz > 25000000UL) ||
        (my_ads_state == ADS_START)) {
        return ADS_ERROR;
    }
    my_ads.input_clock_hz = input_clock_hz;
    return ADS_OK;
}

ADS_res ADS_Start_Input_Clock(uint32_t requested_clock_hz)
{
    uint32_t timer_clock_hz = HAL_RCC_GetPCLK1Freq();
    uint32_t period_ticks;
    uint32_t actual_clock_hz;

    if ((requested_clock_hz < 1000000UL) ||
        (requested_clock_hz > 25000000UL) ||
        (my_ads_state == ADS_START)) {
        return ADS_ERROR;
    }

    /* APB1预分频不为1时，STM32H7的TIM4内核时钟为PCLK1的2倍。 */
    if ((RCC->D2CFGR & RCC_D2CFGR_D2PPRE1) != 0U) {
        timer_clock_hz *= 2U;
    }
    period_ticks = (timer_clock_hz + (requested_clock_hz / 2U)) /
                   requested_clock_hz;
    if ((period_ticks < 2U) || (period_ticks > 65536U)) {
        return ADS_ERROR;
    }

    HAL_TIM_PWM_Stop(&htim4, TIM_CHANNEL_1);
    __HAL_TIM_SET_PRESCALER(&htim4, 0U);
    __HAL_TIM_SET_AUTORELOAD(&htim4, period_ticks - 1U);
    __HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_1, period_ticks / 2U);
    __HAL_TIM_SET_COUNTER(&htim4, 0U);
    htim4.Instance->EGR = TIM_EGR_UG;
    if (HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_1) != HAL_OK) {
        return ADS_ERROR;
    }

    actual_clock_hz = timer_clock_hz / period_ticks;
    my_ads.input_clock_hz = actual_clock_hz;
    ADS_INFO_PRINTF("ADS CLK started: requested=%lu Hz actual=%lu Hz\r\n",
                    (unsigned long)requested_clock_hz,
                    (unsigned long)actual_clock_hz);
    return ADS_OK;
}

ADS_res ADS_Set_Sample_Rate(uint8_t iclk_divider,
                            uint8_t modclk_divider,
                            uint8_t osr)
{
    uint16_t osr_value = ADS131A04_Get_OSR_Value(osr);
    uint32_t total_divider;

    if ((iclk_divider < ADS_CLK_DIV_2) || (iclk_divider > ADS_CLK_DIV_14) ||
        (modclk_divider < ADS_CLK_DIV_2) || (modclk_divider > ADS_CLK_DIV_14) ||
        (osr_value == 0U) || (my_ads_state == ADS_START)) {
        return ADS_ERROR;
    }

    my_ads.iclk_divider = iclk_divider;
    my_ads.modclk_divider = modclk_divider;
    my_ads.osr = osr;
    total_divider = (uint32_t)(2U * iclk_divider) *
                    (uint32_t)(2U * modclk_divider) * osr_value;
    my_ads.sample_rate_hz = my_ads.input_clock_hz / total_divider;
    return ADS_OK;
}

ADS_res ADS_Set_CH_Enable(uint8_t channel_mask)
{
    if ((channel_mask == 0U) || (channel_mask > ADS_CHANNEL_ALL) ||
        (my_ads_state == ADS_START)) {
        return ADS_ERROR;
    }

    my_ads.channel_mask = channel_mask;
    my_ads.frame_words = (uint8_t)(1U + ADS_Count_Channels(channel_mask));
    for (uint8_t channel = 0U; channel < ADS_CHANNEL_COUNT; channel++) {
        my_ads.channel[channel].enabled =
            ((channel_mask & (1U << channel)) != 0U) ? 1U : 0U;
    }
    return ADS_OK;
}

ADS_res ADS_Set_Channel_Gain(uint8_t channel_index, uint8_t gain)
{
    if ((channel_index < 1U) || (channel_index > ADS_CHANNEL_COUNT) ||
        (gain > ADCX_GAIN_16) || (my_ads_state == ADS_START)) {
        return ADS_ERROR;
    }
    my_ads.channel[channel_index - 1U].gain = gain;
    return ADS_OK;
}

ADS_res ADS_Set_Reference(uint16_t reference_millivolts,
                          uint8_t reference_source)
{
    if (((reference_millivolts != 2442U) &&
         (reference_millivolts != 4000U)) ||
        (reference_source > ADS_REF_INTERNAL) ||
        (my_ads_state == ADS_START)) {
        return ADS_ERROR;
    }
    my_ads.reference_millivolts = reference_millivolts;
    my_ads.reference_source = reference_source;
    return ADS_OK;
}

void ADS_Print_Init_Info(void)
{
        ADS_INFO_PRINTF("ADS131A04 config: CLK=%lu Hz, ICLK=/ %u, MODCLK=/ %u, "
                  "OSR=%u, Fs=%lu Hz\r\n",
                  (unsigned long)my_ads.input_clock_hz,
                  (unsigned int)(2U * my_ads.iclk_divider),
                  (unsigned int)(2U * my_ads.modclk_divider),
                  (unsigned int)ADS131A04_Get_OSR_Value(my_ads.osr),
                  (unsigned long)my_ads.sample_rate_hz);
        ADS_INFO_PRINTF("ADS131A04 channels=0b%c%c%c%c, samples/channel=%lu, frame=%u words\r\n",
                  (my_ads.channel_mask & ADS_CHANNEL_4) ? '1' : '0',
                  (my_ads.channel_mask & ADS_CHANNEL_3) ? '1' : '0',
                  (my_ads.channel_mask & ADS_CHANNEL_2) ? '1' : '0',
                  (my_ads.channel_mask & ADS_CHANNEL_1) ? '1' : '0',
                  (unsigned long)my_ads.sample_count,
                  (unsigned int)my_ads.frame_words);
        ADS_INFO_PRINTF("ADS131A04 reference=%u mV, source=%s\r\n",
                  (unsigned int)my_ads.reference_millivolts,
                  (my_ads.reference_source == ADS_REF_INTERNAL) ? "internal" : "external");
}

ADS_res ADS_Init(void)
{
    uint8_t channel_registers[ADS_CHANNEL_COUNT] = {
        ADS_ADC1, ADS_ADC2, ADS_ADC3, ADS_ADC4
    };

    HAL_NVIC_DisableIRQ(ADS_DRDY_EXTI_IRQn);

    if ((my_ads.sample_count < ADS_SAMPLE_COUNT_MIN) ||
        (my_ads.sample_count > ADS_SAMPLE_COUNT_MAX) ||
        (my_ads.channel_mask == 0U) || (my_ads.sample_rate_hz == 0U)) {
        return ADS_ERROR;
    }

    ADS_INFO_PRINTF("\r\nADS131A04 initialization started\r\n");
    ADS_Print_Init_Info();
    if (ADS131A04_Power_Up() != ADS_OK) {
        return ADS_ERROR;
    }
        if (ADS131A04_Set_Reference(
            (my_ads.reference_millivolts == 4000U) ? ADS_REF_4V : ADS_REF_2V442,
            my_ads.reference_source) != ADS_OK) {
        return ADS_ERROR;
    }
    if (ADS131A04_Set_Clock(my_ads.iclk_divider,
                            my_ads.modclk_divider,
                            my_ads.osr) != ADS_OK) {
        return ADS_ERROR;
    }

    /* ADC_ENA仍为0，使用1-word帧回读并校验实际时钟寄存器。 */
    {
        uint8_t expected_clk1 = (uint8_t)(my_ads.iclk_divider << 1);
        uint8_t expected_clk2 = (uint8_t)((my_ads.modclk_divider << 5) |
                                          my_ads.osr);
        uint32_t clk1_response = ADS131A04_Read_Reg(CLK1, 1U);
        uint32_t clk2_response = ADS131A04_Read_Reg(CLK2, 1U);
        uint8_t actual_clk1 = ADS131A04_Response_Data(clk1_response);
        uint8_t actual_clk2 = ADS131A04_Response_Data(clk2_response);

        ADS_INFO_PRINTF("REG CLK1=0x%02X CLK2=0x%02X\r\n",
                (unsigned int)actual_clk1,
                (unsigned int)actual_clk2);
        if ((actual_clk1 != expected_clk1) ||
            (actual_clk2 != expected_clk2)) {
            printf("ADS clock register verification failed\r\n");
            return ADS_ERROR;
        }
    }

    for (uint8_t channel = 0U; channel < ADS_CHANNEL_COUNT; channel++) {
        if (ADS131A04_Set_Gain(channel_registers[channel],
                               my_ads.channel[channel].gain) != ADS_OK) {
            return ADS_ERROR;
        }
    }

    /* ADC_ENA尚为0，此时使用1-word帧逐通道回读增益寄存器。 */
    for (uint8_t channel = 0U; channel < ADS_CHANNEL_COUNT; channel++) {
        uint32_t response = ADS131A04_Read_Reg(channel_registers[channel], 1U);
        uint8_t register_gain = ADS131A04_Response_Data(response);

        ADS_INFO_PRINTF("REG ADC%u raw=0x%08lX gain=0x%02X\r\n",
                (unsigned int)(channel + 1U),
                (unsigned long)response,
                (unsigned int)register_gain);
        if (register_gain != my_ads.channel[channel].gain) {
            printf("ADC%u gain register verification failed\r\n",
                   (unsigned int)(channel + 1U));
            return ADS_ERROR;
        }
    }

    if (ADS131A04_Enable_Channels(my_ads.channel_mask,
                                  my_ads.frame_words) != ADS_OK) {
        return ADS_ERROR;
    }
    if (ADS131A04_Wakeup(my_ads.frame_words) != ADS_OK) {
        return ADS_ERROR;
    }

    my_ads.sample_index = 0U;
    my_ads.samples_ready = 0U;
    my_ads_state = ADS_Init_OK;
    ADS_INFO_PRINTF("ADS131A04 initialization complete\r\n");
    return ADS_OK;
}

ADS_res ADS_Start(void)
{
    if ((my_ads_state != ADS_Init_OK) || (my_ads.channel_mask == 0U)) {
        return ADS_ERROR;
    }

    my_ads.sample_index = 0U;
    my_ads.samples_ready = 0U;
    my_ads.measured_sample_rate_hz = 0U;
    ads_spi_error_count = 0U;
    memset((void *)ads_debug_raw_frames, 0, sizeof(ads_debug_raw_frames));

    /* 用CPU周期计数器测量真实DRDY间隔，避免仅依赖时钟树推算采样率。 */
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
    DWT->CYCCNT = 0U;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;
    my_ads_state = ADS_START;
    __HAL_GPIO_EXTI_CLEAR_IT(ADS_DRDY_Pin);
    HAL_NVIC_ClearPendingIRQ(ADS_DRDY_EXTI_IRQn);
    HAL_NVIC_EnableIRQ(ADS_DRDY_EXTI_IRQn);
    ADS_INFO_PRINTF("ADS131A04 acquisition started\r\n");
    return ADS_OK;
}

ADS_res ADS_Stop(void)
{
    HAL_NVIC_DisableIRQ(ADS_DRDY_EXTI_IRQn);
    my_ads_state = ADS_Init_OK;
    return ADS_OK;
}

uint8_t ADS_Samples_Ready(void)
{
    return my_ads.samples_ready;
}

ADS_res ADS_Process_Data(void)
{
    if (my_ads.samples_ready == 0U) {
        return ADS_ERROR;
    }

    for (uint8_t channel = 0U; channel < ADS_CHANNEL_COUNT; channel++) {
        ADS_ChannelData *data = &my_ads.channel[channel];
        if (data->enabled == 0U) {
            continue;
        }

        for (uint32_t sample = 0U; sample < my_ads.sample_count; sample++) {
            data->millivolts[sample] =
                ADS_Raw_To_Millivolts(data->raw[sample], data->gain);
            if (sample == 0U) {
                data->min_millivolts = data->millivolts[sample];
                data->max_millivolts = data->millivolts[sample];
            } else {
                if (data->millivolts[sample] < data->min_millivolts) {
                    data->min_millivolts = data->millivolts[sample];
                }
                if (data->millivolts[sample] > data->max_millivolts) {
                    data->max_millivolts = data->millivolts[sample];
                }
            }
        }
        data->peak_to_peak_millivolts =
            data->max_millivolts - data->min_millivolts;
    }
    return ADS_OK;
}

// ads_app.c 新增
ADS_res ADS_Process_Only(void)
{
    if (ADS_Process_Data() != ADS_OK) {
        return ADS_ERROR;
    }
    ADS_INFO_PRINTF("ADS measured Fs=%lu Hz (configured=%lu Hz)\r\n",
                    (unsigned long)my_ads.measured_sample_rate_hz,
                    (unsigned long)my_ads.sample_rate_hz);
    my_ads.samples_ready = 0U;
    return ADS_OK;
}

const ADS_ChannelData *ADS_Get_Channel(uint8_t channel_index)
{
    if ((channel_index < 1U) || (channel_index > ADS_CHANNEL_COUNT)) {
        return NULL;
    }
    return &my_ads.channel[channel_index - 1U];
}

void ADS_Print_Diagnostics(void)
{
    for (uint32_t frame = 0U; frame < 4U; frame++) {
        printf("RAW[%lu]", (unsigned long)frame);
        for (uint8_t word = 0U; word < my_ads.frame_words; word++) {
            printf(" W%u=0x%08lX", (unsigned int)word,
                   (unsigned long)ads_debug_raw_frames[frame][word]);
        }
        printf("\r\n");
    }
    printf("SPI errors: %lu\r\n", (unsigned long)ads_spi_error_count);
    printf("ADS diagnostic: STAT1=0x%08lX STAT_S=0x%08lX ERR_CNT=0x%08lX\r\n",
           (unsigned long)ADS131A04_Read_Reg(STAT_1, my_ads.frame_words),
           (unsigned long)ADS131A04_Read_Reg(STAT_S, my_ads.frame_words),
           (unsigned long)ADS131A04_Read_Reg(ERROR_CNT, my_ads.frame_words));
    printf("ADS input flags: STAT_P=0x%08lX STAT_N=0x%08lX\r\n",
           (unsigned long)ADS131A04_Read_Reg(STAT_P, my_ads.frame_words),
           (unsigned long)ADS131A04_Read_Reg(STAT_N, my_ads.frame_words));
}

void ADS_Print_Channel(uint8_t channel_index, uint8_t print_each_sample)
{
    const ADS_ChannelData *data = ADS_Get_Channel(channel_index);

    if ((data == NULL) || (data->enabled == 0U)) {
        return;
    }
    if (print_each_sample != 0U) {
        for (uint32_t sample = 0U; sample < my_ads.sample_count; sample++) {
            printf("CH%u[%lu] = %ld mV\r\n",
                   (unsigned int)channel_index,
                   (unsigned long)sample,
                   (long)data->millivolts[sample]);
        }
    }
    printf("CH%u min=%ld mV max=%ld mV p-p=%ld mV\r\n",
           (unsigned int)channel_index,
           (long)data->min_millivolts,
           (long)data->max_millivolts,
           (long)data->peak_to_peak_millivolts);
}
//打印日志和数据
ADS_res ADS_Process_And_Print(uint8_t print_each_sample)
{
    if (ADS_Process_Data() != ADS_OK) {
        return ADS_ERROR;
    }

    printf("ADS acquisition complete: %lu samples per enabled channel\r\n",
           (unsigned long)my_ads.sample_count);
    ADS_Print_Diagnostics();
    for (uint8_t channel = 1U; channel <= ADS_CHANNEL_COUNT; channel++) {
        ADS_Print_Channel(channel, print_each_sample);
    }
    my_ads.samples_ready = 0U;
    return ADS_OK;
}

void ADS_DRDY_Callback(void)
{
    static uint32_t first_drdy_cycle = 0U;
    uint32_t tx_data[ADS_MAX_FRAME_WORDS] = {0U};
    uint32_t rx_data[ADS_MAX_FRAME_WORDS] = {0U};
    uint8_t frame_word = 1U;

    if (my_ads_state != ADS_START) {
        return;
    }

    if (my_ads.sample_index == 0U) {
        first_drdy_cycle = DWT->CYCCNT;
    }

    HAL_GPIO_WritePin(ADS_CS_GPIO_Port, ADS_CS_Pin, GPIO_PIN_RESET);
    if (HAL_SPI_TransmitReceive(&hspi2,
                                (uint8_t *)tx_data,
                                (uint8_t *)rx_data,
                                my_ads.frame_words,
                                300U) != HAL_OK) {
        HAL_GPIO_WritePin(ADS_CS_GPIO_Port, ADS_CS_Pin, GPIO_PIN_SET);
        ads_spi_error_count++;
        ADS_Stop();
        return;
    }
    HAL_GPIO_WritePin(ADS_CS_GPIO_Port, ADS_CS_Pin, GPIO_PIN_SET);

    if (my_ads.sample_index < 4U) {
        for (uint8_t word = 0U; word < my_ads.frame_words; word++) {
            ads_debug_raw_frames[my_ads.sample_index][word] = rx_data[word];
        }
    }

    for (uint8_t channel = 0U; channel < ADS_CHANNEL_COUNT; channel++) {
        if (my_ads.channel[channel].enabled != 0U) {
            my_ads.channel[channel].raw[my_ads.sample_index] =
                ADS_Sign_Extend_24(rx_data[frame_word]);
            frame_word++;
        }
    }

    my_ads.sample_index++;
    if (my_ads.sample_index >= my_ads.sample_count) {
        uint32_t elapsed_cycles = DWT->CYCCNT - first_drdy_cycle;

        if ((elapsed_cycles != 0U) && (my_ads.sample_count > 1U)) {
            my_ads.measured_sample_rate_hz = (uint32_t)(
                ((uint64_t)(my_ads.sample_count - 1U) * SystemCoreClock +
                 ((uint64_t)elapsed_cycles / 2ULL)) /
                (uint64_t)elapsed_cycles);
        }
        ADS_Stop();
        my_ads.samples_ready = 1U;
    }
}
