h7adc/quaternionmathfunctions.o: \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Source\QuaternionMathFunctions\QuaternionMathFunctions.c \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Source\QuaternionMathFunctions\arm_quaternion_norm_f32.c \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\quaternion_math_functions.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\arm_math_types.h \
  ..\Drivers\CMSIS\Include\cmsis_compiler.h \
  ..\Drivers\CMSIS\Include\cmsis_armclang.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\arm_math_memory.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\none.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\utils.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Source\QuaternionMathFunctions\arm_quaternion_inverse_f32.c \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Source\QuaternionMathFunctions\arm_quaternion_conjugate_f32.c \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Source\QuaternionMathFunctions\arm_quaternion_normalize_f32.c \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Source\QuaternionMathFunctions\arm_quaternion_product_single_f32.c \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Source\QuaternionMathFunctions\arm_quaternion_product_f32.c \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Source\QuaternionMathFunctions\arm_quaternion2rotation_f32.c \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Source\QuaternionMathFunctions\arm_rotation2quaternion_f32.c
