h7adc/main.o: ..\Core\Src\main.c ..\Core\Inc\main.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal.h \
  ..\Core\Inc\stm32h7xx_hal_conf.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_rcc.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_def.h \
  ..\Drivers\CMSIS\Device\ST\STM32H7xx\Include\stm32h7xx.h \
  ..\Drivers\CMSIS\Device\ST\STM32H7xx\Include\stm32h743xx.h \
  ..\Drivers\CMSIS\Include\core_cm7.h \
  ..\Drivers\CMSIS\Device\ST\STM32H7xx\Include\system_stm32h7xx.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\Legacy\stm32_hal_legacy.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_rcc_ex.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_gpio.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_gpio_ex.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_dma.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_dma_ex.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_mdma.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_exti.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_cortex.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_flash.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_flash_ex.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_hsem.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_i2c.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_i2c_ex.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_pwr.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_pwr_ex.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_spi.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_spi_ex.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_tim.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_tim_ex.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_uart.h \
  ..\Drivers\STM32H7xx_HAL_Driver\Inc\stm32h7xx_hal_uart_ex.h \
  ..\Core\Inc\memorymap.h ..\Core\Inc\spi.h ..\Core\Inc\tim.h \
  ..\Core\Inc\usart.h ..\Core\Inc\gpio.h ..\BSP\USARTLCD\USARTLCD.h \
  ..\BSP\ADS131A0x\ads_app.h ..\BSP\ADS131A0x\ads131a0x.h \
  ..\BSP\ADS_FFT\ADS_FFT.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\arm_math.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\arm_math_types.h \
  ..\Drivers\CMSIS\Include\cmsis_compiler.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\arm_math_memory.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\none.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\utils.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\basic_math_functions.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\interpolation_functions.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\bayes_functions.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\statistics_functions.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\fast_math_functions.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\matrix_functions.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\complex_math_functions.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\controller_functions.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\support_functions.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\distance_functions.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\svm_functions.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\svm_defines.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\transform_functions.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\filtering_functions.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\quaternion_math_functions.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\window_functions.h
