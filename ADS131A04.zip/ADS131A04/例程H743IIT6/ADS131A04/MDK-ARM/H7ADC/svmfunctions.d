h7adc/svmfunctions.o: \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Source\SVMFunctions\SVMFunctions.c \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Source\SVMFunctions\arm_svm_linear_init_f32.c \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\svm_functions.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\arm_math_types.h \
  ..\Drivers\CMSIS\Include\cmsis_compiler.h \
  ..\Drivers\CMSIS\Include\cmsis_armclang.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\arm_math_memory.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\none.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\utils.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\svm_defines.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Source\SVMFunctions\arm_svm_linear_predict_f32.c \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Source\SVMFunctions\arm_svm_polynomial_init_f32.c \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Source\SVMFunctions\arm_svm_polynomial_predict_f32.c \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Source\SVMFunctions\arm_svm_rbf_init_f32.c \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Source\SVMFunctions\arm_svm_rbf_predict_f32.c \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Source\SVMFunctions\arm_svm_sigmoid_init_f32.c \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Source\SVMFunctions\arm_svm_sigmoid_predict_f32.c
