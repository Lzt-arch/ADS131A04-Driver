h7adc/bayesfunctions.o: \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Source\BayesFunctions\BayesFunctions.c \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Source\BayesFunctions\arm_gaussian_naive_bayes_predict_f32.c \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\bayes_functions.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\arm_math_types.h \
  ..\Drivers\CMSIS\Include\cmsis_compiler.h \
  ..\Drivers\CMSIS\Include\cmsis_armclang.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\arm_math_memory.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\none.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\utils.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\statistics_functions.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\basic_math_functions.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\fast_math_functions.h
