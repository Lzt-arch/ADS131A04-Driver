h7adc/interpolationfunctionsf16.o: \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Source\InterpolationFunctions\InterpolationFunctionsF16.c \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Source\InterpolationFunctions\arm_bilinear_interp_f16.c \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\interpolation_functions_f16.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\arm_math_types_f16.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\arm_math_types.h \
  ..\Drivers\CMSIS\Include\cmsis_compiler.h \
  ..\Drivers\CMSIS\Include\cmsis_armclang.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\arm_math_memory.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\none.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Include\dsp\utils.h \
  G:\keil_MDK\Packs\ARM\CMSIS-DSP\1.15.0\Source\InterpolationFunctions\arm_linear_interp_f16.c
