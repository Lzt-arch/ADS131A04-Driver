/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "memorymap.h"
#include "spi.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include "USARTLCD.h"
#include "ads_app.h"
#include "ADS_FFT.h"
#include <stdio.h>
#include <string.h>

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

uint8_t uart6_rx_buffer[16];
uint8_t uart6_parse_buffer[16];
uint16_t uart6_parse_len = 0;



uint8_t mode = 0;


/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
static void MPU_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  if (GPIO_Pin == ADS_DRDY_Pin)
  {
    ADS_DRDY_Callback();
    return;
  }
//	if (GPIO_Pin == SW1_Pin)
//	{
//		HAL_Delay(20);
//		if (HAL_GPIO_ReadPin(SW1_GPIO_Port, SW1_Pin) == GPIO_PIN_RESET)
//		{

//		}
//		HAL_Delay(20);
//		while (HAL_GPIO_ReadPin(SW1_GPIO_Port, SW1_Pin) == GPIO_PIN_RESET);
//		
//		HAL_Delay(10);
//	}
}



/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MPU Configuration--------------------------------------------------------*/
  MPU_Config();

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_USART1_UART_Init();
  MX_USART6_UART_Init();
  MX_SPI2_Init();
  MX_TIM4_Init();
  /* USER CODE BEGIN 2 */

/* ADS����CLK��TIM4_CH1(PD12)����������ﴫ������Ƶ�ʡ� */
if (ADS_Start_Input_Clock(ADS_DEFAULT_INPUT_CLOCK_HZ) != ADS_OK)
{
  printf("ADS input clock start failed\r\n");
  Error_Handler();
}
 
HAL_Delay(10U);
/* ��������ΪCLK1��Ƶ��CLK2����ʱ�ӷ�Ƶ��OSR�� */
if (ADS_Set_Sample_Rate(ADS_DEFAULT_ICLK_DIVIDER,
                        ADS_DEFAULT_MODCLK_DIVIDER,
                        ADS_DEFAULT_OSR) != ADS_OK)
{
  printf("ADS sample-rate configuration failed\r\n");
  Error_Handler();
}
/* 0x0F(1111)��ͬ������CH1~CH4�� */
if (ADS_Set_CH_Enable(0x0FU) != ADS_OK)
{
  printf("ADS CH1~CH4 selection failed\r\n");
  Error_Handler();
}

if (ADS_Init() != ADS_OK)
{
  printf("ADS CH1~CH4 initialization failed\r\n");
  Error_Handler();
}

if (ADS_Start() != ADS_OK)
{
  printf("ADS CH1~CH4 acquisition start failed\r\n");
  Error_Handler();
}


	
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    if (ADS_Samples_Ready() != 0U)
    {
      if (ADS_Process_Only() != ADS_OK)
      {
        printf("ADS data processing failed\r\n");
      }
      else
      {
        /* 0x07������CH1~CH3��0x03������CH2���CH1����λ� */
        if (deal_FFT(0x07U, 0x03U) == ADS_FFT_OK)
        {
           printf("CH1: Freq=%.3f Hz Phase=%.3f deg Vpp=%.3f V THD=%.3f%%\r\n",
             (double)ADC_Res1.freq,
             (double)ADC_Res1.phaseDeg,
             (double)ADC_Res1.adcVpp,
             (double)(ADC_Res1.thd * 100.0f));
           printf("CH2: Freq=%.3f Hz Phase=%.3f deg Vpp=%.3f V THD=%.3f%%\r\n",
             (double)ADC_Res2.freq,
             (double)ADC_Res2.phaseDeg,
             (double)ADC_Res2.adcVpp,
             (double)(ADC_Res2.thd * 100.0f));
           printf("CH3: Freq=%.3f Hz Phase=%.3f deg Vpp=%.3f V THD=%.3f%%\r\n",
                 (double)ADC_Res3.freq,
                 (double)ADC_Res3.phaseDeg,
             (double)ADC_Res3.adcVpp,
             (double)(ADC_Res3.thd * 100.0f));
           printf("Phase CH2-CH1=%.3f deg\r\n",
          (double)ADC_Res1.phaseDiffDeg1_2);
        }
        else
        {
          printf("ADS FFT processing failed\r\n");
        }
      }
      /* ����������һ�ֲɼ��� */
      //ADS_Start();
    }
	  
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Supply configuration update enable
  */
  HAL_PWREx_ConfigSupply(PWR_LDO_SUPPLY);

  /** Configure the main internal regulator output voltage
  */
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE0);

  while(!__HAL_PWR_GET_FLAG(PWR_FLAG_VOSRDY)) {}

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 5;
  RCC_OscInitStruct.PLL.PLLN = 192;
  RCC_OscInitStruct.PLL.PLLP = 2;
  /* SPI123ʹ��PLL1Q��960MHz / 20 / SPIԤ��Ƶ2 = 24MHz�� */
  RCC_OscInitStruct.PLL.PLLQ = 20;
  RCC_OscInitStruct.PLL.PLLR = 2;
  RCC_OscInitStruct.PLL.PLLRGE = RCC_PLL1VCIRANGE_2;
  RCC_OscInitStruct.PLL.PLLVCOSEL = RCC_PLL1VCOWIDE;
  RCC_OscInitStruct.PLL.PLLFRACN = 0;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2
                              |RCC_CLOCKTYPE_D3PCLK1|RCC_CLOCKTYPE_D1PCLK1;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.SYSCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB3CLKDivider = RCC_APB3_DIV2;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_APB1_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_APB2_DIV2;
  RCC_ClkInitStruct.APB4CLKDivider = RCC_APB4_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */





/**
 * @brief  UART6 DMA+IDLE������ɻص����������������ݽ�����
 * @param  huart ���ھ��
 * @param  Size �����жϽ��յ������ݳ���
 * @retval ��
 */
void HAL_UARTEx_RxEventCallback(UART_HandleTypeDef *huart, uint16_t Size){
  uint16_t i = 0;                // ֡�����α�
  uint16_t remain = 0;           // ��δ�����Ĳ������ݳ���

  if(huart != &huart6){
    return;
  }

  /* ��ֹ���ճ��ȳ������ջ������� */
  if(Size > sizeof(uart6_rx_buffer)){
    Size = sizeof(uart6_rx_buffer);
  }

  /* ƴ�����ݣ���� IDLE ������⡣ */
  /* ��������������������ܳ��ȳ��ޣ�����ս����������� */
  if((uart6_parse_len + Size) > sizeof(uart6_parse_buffer)){
    uart6_parse_len = 0;
  }

  /* �������յ�������׷�ӵ������������� */
  memcpy(&uart6_parse_buffer[uart6_parse_len], uart6_rx_buffer, Size);
  uart6_parse_len += Size;

  /* ����������6�ֽ�Э��֡��0x55 XX XX XX XX 0x0F�� */
  while((i + 5U) < uart6_parse_len){
    /* ͬʱƥ��֡ͷ��֡β�� */
    if(uart6_parse_buffer[i] == 0x55 && uart6_parse_buffer[i + 5U] == 0x0FU){


		
		
      i += 6U;  // ������ǰ����֡������������һ֡
    }
    else{
      i++;      // δƥ��ʱ���ֽڼ�������
    }
  }

  /* ������δ�������֡�Ĳ������ݡ� */
  remain = uart6_parse_len - i;
  if(remain > 0U){
    /* �����������ƶ�����������ͷ�����´μ��������� */
    memmove(uart6_parse_buffer, &uart6_parse_buffer[i], remain);
  }
  uart6_parse_len = remain;

  /* �������� DMA+IDLE ���գ��ȴ���һ�����ݡ� */
  __HAL_UART_CLEAR_FLAG(&huart6, UART_CLEAR_IDLEF);
  HAL_UARTEx_ReceiveToIdle_DMA(&huart6,uart6_rx_buffer,sizeof(uart6_rx_buffer));
  //__HAL_DMA_DISABLE_IT(&hdma_usart6_rx,DMA_IT_HT);  // USART6 RX DMA��δ����
}






/* USER CODE END 4 */

 /* MPU Configuration */

void MPU_Config(void)
{
  MPU_Region_InitTypeDef MPU_InitStruct = {0};

  /* Disables the MPU */
  HAL_MPU_Disable();

  /** Initializes and configures the Region and the memory to be protected
  */
  MPU_InitStruct.Enable = MPU_REGION_ENABLE;
  MPU_InitStruct.Number = MPU_REGION_NUMBER0;
  MPU_InitStruct.BaseAddress = 0x0;
  MPU_InitStruct.Size = MPU_REGION_SIZE_4GB;
  MPU_InitStruct.SubRegionDisable = 0x87;
  MPU_InitStruct.TypeExtField = MPU_TEX_LEVEL0;
  MPU_InitStruct.AccessPermission = MPU_REGION_NO_ACCESS;
  MPU_InitStruct.DisableExec = MPU_INSTRUCTION_ACCESS_DISABLE;
  MPU_InitStruct.IsShareable = MPU_ACCESS_SHAREABLE;
  MPU_InitStruct.IsCacheable = MPU_ACCESS_NOT_CACHEABLE;
  MPU_InitStruct.IsBufferable = MPU_ACCESS_NOT_BUFFERABLE;

  HAL_MPU_ConfigRegion(&MPU_InitStruct);
  /* Enables the MPU */
  HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);

}

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
