#include "stdio.h"
#include "main.h"
#include "string.h"
#include "usart.h"
#include "USARTLCD.h"
#include <stdint.h>
#include <math.h>


char spr_str[256];




void USARTLCD_Page0_X0(float cap) //电容
{            
    cap*=1000;                                  
	sprintf(spr_str,"page0.x0.val=%d\xff\xff\xff",(int)cap);   
	HAL_UART_Transmit(&huart6,(uint8_t*)spr_str,strlen(spr_str),0xFFFF);
	
}


void USARTLCD_Page0_X1(float res) //电阻
{         
    res*=1000;                                     
	sprintf(spr_str,"page0.x1.val=%d\xff\xff\xff",(int)res);   
	HAL_UART_Transmit(&huart6,(uint8_t*)spr_str,strlen(spr_str),0xFFFF);
	
}

void USARTLCD_Page0_X2(float length) //电阻
{         
    length*=1000;                                     
	sprintf(spr_str,"page0.x2.val=%d\xff\xff\xff",(int)length);   
	HAL_UART_Transmit(&huart6,(uint8_t*)spr_str,strlen(spr_str),0xFFFF);
	
}




void USARTLCD_Page0_n1(int mode)
{
	sprintf(spr_str,"page0.n1.val=%d\xff\xff\xff",mode);
	HAL_UART_Transmit(&huart6,(uint8_t*)spr_str,strlen(spr_str),0xFFFF);
}


void USARTLCD_SetT5Text(const char *text) //工作状态
{
    if (text == NULL)
    {
        return;
    }

    snprintf(spr_str, sizeof(spr_str), "t5.txt=\"%s\"\xff\xff\xff", text);
    HAL_UART_Transmit(&huart6, (uint8_t*)spr_str, strlen(spr_str), 0xFFFF);
}


void USARTLCD_SetT6Text(const char *text) //负载类型
{
    if (text == NULL)
    {
        return;
    }

    snprintf(spr_str, sizeof(spr_str), "t6.txt=\"%s\"\xff\xff\xff", text);
    HAL_UART_Transmit(&huart6, (uint8_t*)spr_str, strlen(spr_str), 0xFFFF);
}




