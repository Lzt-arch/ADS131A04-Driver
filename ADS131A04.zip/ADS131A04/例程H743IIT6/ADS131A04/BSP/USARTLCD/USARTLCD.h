#ifndef __USARTLCD_H
#define __USARTLCD_H


#include "main.h"
#include "stdio.h"
#include "string.h"
#include "usart.h"
#include <stdint.h>

void USARTLCD_Page0_X0(float cap); //电容

void USARTLCD_Page0_X1(float res); //电阻

void USARTLCD_Page0_X2(float length);//长度

void USARTLCD_SetT5Text(const char *text);//工作状态

void USARTLCD_SetT6Text(const char *text);//负载类型

void USARTLCD_Page0_n1(int mode);

#endif

