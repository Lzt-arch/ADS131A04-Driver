这是ADS131A04的驱动，from lzt+chatGPT 5.6 sol 
初版撰写：2026.7.20

如果移植，需要移植ADS131A0x和ADS_FFT共2个文件夹8个文件，ADS131A0x是采样相关的程序，ADS_FFT是后续数据处理的程序。

基本调用流程如下，当前例程实现的是4通道同步采样，处理1-3通道数据，计算1-2通道的相位差

代码实现平台是STM32H743IIT6，使用硬件SPI2，TIM4_CH1输出方波提供16MHZ时钟，配置参考对应word文档

应用层实现：
采样点数：采样点数由.h文件中宏设定
采样频率：计算为fclk/ICLK_DIV/MODCLK_DIV/OSR，通过函数ADS_Set_Sample_Rate设定
通道使能：通过4位二进制数选择，1为启用，0为禁用，通过函数ADS_Set_CH_Enable设定

使用流程：启用时钟（软件启用） -> 设置采样频率 -> 使能采样通道 -> 初始化 -> 开启采样（在上一次数据处理完成后循环调用即为连续采样模式） 

需要注意的是:
1. spi传输速率是影响模块正常传输数据的关键，当4路ADC全部开启时，每帧会有STUTAS+ADC1+ADC2+ADC3+ADC4,共5*32 = 160bit数据，spi传输速率需要大于160*采样频率，以当前为例子采样频率83.33kHZ，160*83.33k = 13.33MHz<spi的24MHz，但是由于ADS131A04的最大spi速率只有25MHz，这个速率是很极限的，所以实际使用时建在12-20MHz之间
 
2. 芯片ADC前端有固定的sinc3的滤波器，所测测量频率升高时会有对应的幅度衰减，实测除幅度不准，其它数据仍然准确

当前 83kSPS 下：传输 6.67μs < 周期 12μs，余量约 44%，非常充裕。
如果用最快配置 OSR=32 (125kSPS)：传输 6.67μs < 周期 8μs，有 16% 余量，实测会因 SPI 带宽不足而漏帧。

具体实现过程：
/* ADS输入CLK由TIM4_CH1(PD12)输出；在这里传入期望频率。 */
ADS_Start_Input_Clock(ADS_DEFAULT_INPUT_CLOCK_HZ);

HAL_Delay(10U);

/* 参数依次为CLK1分频、CLK2调制时钟分频、OSR。 */
ADS_Set_Sample_Rate(ADS_DEFAULT_ICLK_DIVIDER,ADS_DEFAULT_MODCLK_DIVIDER,ADS_DEFAULT_OSR);

/* 0x0F(1111)：同步启用CH1~CH4。 */
ADS_Set_CH_Enable(0x0FU);

ADS_Init();

ADS_Start();

在while循环中
if (ADS_Samples_Ready() != 0U)//采样结束
    {
      if (ADS_Process_Only() != ADS_OK)   //读取结束
      {
        printf("ADS data processing failed\r\n");
      }
      else
      {
        /* 0x07：处理CH1~CH3；0x03：计算CH2相对CH1的相位差。 */
        if (deal_FFT(0x07U, 0x03U) == ADS_FFT_OK)
        {
           printf("CH1: Freq=%.3f Hz Phase=%.3f deg Vpp=%.3f V THD=%.3f%%\r\n",
             (double)ADC_Res1.freq,
             (double)ADC_Res1.phaseDeg,
             (double)ADC_Res1.adcVpp,
             (double)(ADC_Res1.thd * 100.0f));
           printf("CH2: Freq=%.3f Hz Phase=%.3f deg Vpp=%.3f V THD=%.3f%%\r\n",
             (double)ADC_Res2.freq,
             (double)ADC_Res2.phaseDeg,
             (double)ADC_Res2.adcVpp,
             (double)(ADC_Res2.thd * 100.0f));
           printf("CH3: Freq=%.3f Hz Phase=%.3f deg Vpp=%.3f V THD=%.3f%%\r\n",
                 (double)ADC_Res3.freq,
                 (double)ADC_Res3.phaseDeg,
             (double)ADC_Res3.adcVpp,
             (double)(ADC_Res3.thd * 100.0f));
           printf("Phase CH2-CH1=%.3f deg\r\n",
          (double)ADC_Res1.phaseDiffDeg1_2);
        }
        else
        {
          printf("ADS FFT processing failed\r\n");
        }
      }